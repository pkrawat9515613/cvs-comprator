import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
from tkinter.ttk import Progressbar
import threading

def browse_file(entry):
    filename = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    entry.delete(0, tk.END)
    entry.insert(0, filename)

def compare_csv():
    file1 = entry_file1.get()
    file2 = entry_file2.get()
    
    if not file1 or not file2:
        messagebox.showerror("Error", "Please select both CSV files.")
        return
    
    try:
        df1 = pd.read_csv(file1, encoding='utf-8', encoding_errors='replace')
        df2 = pd.read_csv(file2, encoding='utf-8', encoding_errors='replace')
        
        # Normalize values (strip spaces, lowercase)
        df1 = df1.astype(str).apply(lambda x: x.str.strip().str.lower()).fillna("")
        df2 = df2.astype(str).apply(lambda x: x.str.strip().str.lower()).fillna("")
        
        # Extract relevant columns
        file1_md5 = df1.iloc[:, 0]
        file1_sha1 = df1.iloc[:, 1]
        file2_last_col = df2.iloc[:, -1]
        
        # Find matches where file2's last column matches MD5 or SHA1 from file1
        matches_md5 = df1[file1_md5.isin(file2_last_col)]
        matches_sha1 = df1[file1_sha1.isin(file2_last_col)]
        
        # Combine matches
        matching_rows = pd.concat([matches_md5, matches_sha1]).drop_duplicates()
        
        # Save only matching rows
        output_file = "comparison_result.csv"
        matching_rows.to_csv(output_file, index=False)
        
        if matching_rows.empty:
            messagebox.showinfo("No Matches", "No matching rows found.")
        else:
            messagebox.showinfo("Success", f"Matching rows saved in {output_file}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def start_comparison():
    threading.Thread(target=compare_csv, daemon=True).start()

root = tk.Tk()
root.title("CSV Comparator")
root.geometry("500x300")

tk.Label(root, text="Select First CSV File:").pack(pady=5)
entry_file1 = tk.Entry(root, width=50)
entry_file1.pack()
tk.Button(root, text="Browse", command=lambda: browse_file(entry_file1)).pack()

tk.Label(root, text="Select Second CSV File:").pack(pady=5)
entry_file2 = tk.Entry(root, width=50)
entry_file2.pack()
tk.Button(root, text="Browse", command=lambda: browse_file(entry_file2)).pack()

progress_bar = Progressbar(root, orient="horizontal", length=400, mode="determinate")
progress_bar.pack(pady=10)

tk.Button(root, text="Submit", command=start_comparison).pack(pady=10)

root.mainloop()