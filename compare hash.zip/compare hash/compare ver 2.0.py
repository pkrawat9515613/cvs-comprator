import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
from tkinter.ttk import Progressbar
import threading

def browse_file(entry):
    filename = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv")])
    entry.delete(0, tk.END)
    entry.insert(0, filename)

def compare_csv():
    file1 = entry_file1.get()
    file2 = entry_file2.get()
    
    if not file1 or not file2:
        messagebox.showerror("Error", "Please select both CSV files.")
        return
    
    try:
        df1 = pd.read_csv(file1, encoding='utf-8', encoding_errors='replace')
        df2 = pd.read_csv(file2, encoding='utf-8', encoding_errors='replace')
        
        if df1.shape != df2.shape:
            messagebox.showwarning("Warning", "Files have different shapes, comparison might be inconsistent.")
        
        progress_bar["value"] = 0
        result_df = df1.eq(df2)
        
        progress_step = 100 / len(df1) if len(df1) > 0 else 100
        
        for index in range(len(df1)):
            progress_bar["value"] += progress_step
            root.update_idletasks()
        
        match_df = df1[result_df.all(axis=1)]  # Keep only matching rows
        output_file = "comparison_result.csv"
        match_df.to_csv(output_file, index=False)
        
        messagebox.showinfo("Success", f"Comparison complete! Matching rows saved as {output_file}")
    except Exception as e:
        messagebox.showerror("Error", str(e))

def start_comparison():
    threading.Thread(target=compare_csv, daemon=True).start()

root = tk.Tk()
root.title("CSV Comparator")
root.geometry("500x300")

tk.Label(root, text="UPLOAD HASH LIST FILE OF FTK IMAGER:").pack(pady=5)
entry_file1 = tk.Entry(root, width=50)
entry_file1.pack()
tk.Button(root, text="Browse", command=lambda: browse_file(entry_file1)).pack()

tk.Label(root, text="UPLOAD THE DESIRED HASH LIST TO COMPARE:").pack(pady=5)
entry_file2 = tk.Entry(root, width=50)
entry_file2.pack()
tk.Button(root, text="Browse", command=lambda: browse_file(entry_file2)).pack()

progress_bar = Progressbar(root, orient="horizontal", length=400, mode="determinate")
progress_bar.pack(pady=10)

tk.Button(root, text="Submit", command=start_comparison).pack(pady=10)

root.mainloop()